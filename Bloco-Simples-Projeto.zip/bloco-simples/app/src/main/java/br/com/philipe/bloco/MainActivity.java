package br.com.philipe.bloco;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public final class MainActivity extends Activity {
 private EditText editor;
 @Override public void onCreate(Bundle ignored) {
  super.onCreate(null);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
  getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
  editor = new EditText(this);
  editor.setTextColor(Color.BLACK);
  editor.setBackgroundColor(Color.WHITE);
  editor.setTextSize(32);
  editor.setGravity(Gravity.TOP | Gravity.START);
  editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
  editor.setImeOptions(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING | EditorInfo.IME_FLAG_NO_FULLSCREEN);
  editor.setSaveEnabled(false);
  editor.setSaveFromParentEnabled(false);
  editor.setFreezesText(false);
  editor.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
  if (android.os.Build.VERSION.SDK_INT >= 29) editor.setImportantForContentCapture(View.IMPORTANT_FOR_CONTENT_CAPTURE_NO_EXCLUDE_DESCENDANTS);
  final int pad = (int)(16 * getResources().getDisplayMetrics().density + 0.5f);
  editor.setPadding(pad, pad, pad, pad);
  editor.setOnApplyWindowInsetsListener((view, insets) -> {
   view.setPadding(pad + insets.getSystemWindowInsetLeft(), pad + insets.getSystemWindowInsetTop(), pad + insets.getSystemWindowInsetRight(), pad + insets.getSystemWindowInsetBottom());
   return insets;
  });
  setContentView(editor);
  editor.requestApplyInsets();
  editor.requestFocus();
  editor.post(() -> ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(editor, InputMethodManager.SHOW_IMPLICIT));
 }
 @Override protected void onSaveInstanceState(Bundle state) { /* Text is never serialized. */ }
 @Override protected void onStop() {
  editor.setText("");
  super.onStop();
 }
 @Override protected void onDestroy() {
  if (editor != null) editor.setText("");
  super.onDestroy();
 }
}
